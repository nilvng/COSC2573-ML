1. Activate virtual python environment
2. run pip install -r requirement.txt
3. Navigate to file name "COSC2753_A1_S3804803.ipynb" to run codes